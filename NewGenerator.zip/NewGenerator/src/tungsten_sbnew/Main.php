<?php

namespace tungsten_sbnew;

use pocketmine\{Player, Server};
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\{Command,CommandSender, CommandExecutor, ConsoleCommandSender};

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\tile\Sign;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;

class Main extends PluginBase implements Listener{


    public $database;
    public function onEnable(){
        $this->getLogger()->info("NewGenerator");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->database = @new \mysqli('localhost', 'root','','TungDB_2');
        if ($this->database->connect_error) {
            $this->getLogger()->info("Kết nối thất bại: " . $this->database->connect_error);
        }

        $db_create = "CREATE DATABASE IF NOT EXISTS TungDB_2";
        if ($this->database->query($db_create) === TRUE) {
        } else {
            $this->getLogger()->info("Tạo database thất bại: " . $this->database->error);
        }
        $table = "CREATE TABLE IF NOT EXISTS TungTB_sbnew2 (
         id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         x INT(9) ,
         y INT(9),
         z INT(9),
         pos TEXT
        )";
        if ($this->database->query($table) === TRUE) {
        } else {
            $this->getLogger()->info("Tạo table thất bại: " . $this->database->error);
        }
    }

    public function onPlace(BlockPlaceEvent $e){
        $block = $e->getBlock();
        $id = $block->getID();
        $name = $e->getPlayer()->getName();
        $x = $block->getX();
        $y = $block->getY();
        $z = $block->getZ();
        $pos = new Vector3($x,$y,$z);
        $player = $e->getPlayer();
        if($id == 85){
            $insert = "INSERT INTO TungTB_sbnew2 (x,y,z,pos) VALUES ('$x','$y','$z','$pos')";
            if ($this->database->query($insert) === true) {
            } else {
                $this->getLogger()->info("Insert thất bại: " . $this->database->error);
            }
            $b = new Vector3($x,$y+1,$z);
            $e->getPlayer()->getLevel()->setBlock($b,Block::get(4));
        }
    }
    public function onBreak(BlockBreakEvent $e){
        $block = $e->getBlock();
        $id = $block->getID();
        $x = $block->getX();
        $y = $block->getY();
        $z = $block->getZ();
        $level = $e->getPlayer()->getLevel();
        $pos = new Vector3($x,$y,$z);
        $sec = "SELECT * FROM TungTB_sbnew2";
        $result = $this->database->query($sec);
        if (!$result) {
            $this->getLogger()->info($this->database->error);
        }
        $rand = rand(1,10);
        switch($rand){
            case 1:
                $a = 4;//dacuoi
                break;
            case 2:
                $a = 16;//coalore
                break;
            case 3:
                $a = 56;//diamondore
                break;
            case 4:
                $a = 4;//dacuoi
                break;
            case 5:
                $a = 129;//emaraldore
                break;
            case 6:
                $a = 14;//goldore
                break;
            case 7:
                $a = 15;//ironore
                break;
            case 8:
                $a = 21;//lapisore
                break;
            case 9:
                $a = 4;//dacuoi
                break;
            case 10:
                $a = 73;//redstoneore
                break;
        }
        while($row = $result->fetch_assoc()){
     //       $this->getLogger()->info($row['id'].' '.$row['x'].' '.$row['y'].' '.$row['z'].' '.$row['pos']);
            if($x == $row['x'] and  $y == $row['y']+1 and $z == $row['z']){
                $this->getScheduler()->scheduleDelayedTask(new SBTask($this,$level,$pos,$a),2);
            }
            if($id == 85){
                $del = "DELETE FROM TungTB_sbnew2 WHERE x = '$x'";
                $this->database->query($del);
            }
        }


    }
    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool{
        return true;
    }
}
