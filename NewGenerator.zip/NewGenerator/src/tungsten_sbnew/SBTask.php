<?php

namespace tungsten_sbnew;

use pocketmine\plugin\Plugin;
use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\block\BlockFactory;
use pocketmine\block\Block;

class SBTask extends Task{

	private $owner;
    public $level;
    public $pos;
    public $a;

	public function __construct(Plugin $owner,$level,$pos,$a){
		$this->owner = $owner;
		$this->level = $level;
		$this->pos = $pos;
		$this->a = $a;
    }
	public function onRun($tick){
		$this->level->setBlock($this->pos,Block::get($this->a));
        $this->cancel();
	}
    public function cancel() {
        $this->getHandler()->cancel();
    }
}